# youtube_video_downloader_gui
add exe
before use enter this command
: python -m pip freeze >requirements.txt
python -m pip install -r requirements.txt
